require('dotenv').config();
require('./Server/db_connections');
require('./Server/server');